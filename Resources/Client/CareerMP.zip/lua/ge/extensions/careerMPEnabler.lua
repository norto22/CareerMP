--CareerMP :: enabler (CLIENT)
--
-- Starts career when a CareerMP server's settings arrive and keeps it in step with
-- the server.
--
--   * Game APIs that BeamNG.drive 0.39 renamed go through careerMP_compat (every
--     "saveSlot" symbol became "profile", among others).
--   * Career start passes a startingOptions table with startMode = "freshStart"
--     ("Open World"). The third parameter of createOrLoadCareerAndStart is a table;
--     passing a boolean silently leaves no starting mode applied.
--   * The BeamMP nickname is sanitised locally before use as a profile name. The
--     game lowercases and strips non-alphanumerics, then de-duplicates against
--     profiles already on that client -- which would make the nickname -> save
--     mapping machine-dependent.
--   * A join keeps one loading screen up until the career has started, and tells the
--     server whether it started (see "Join" below).
--   * patchTopBar is gated: ui_topBar does not exist in 0.39.
--   * Menu hooks come from careerMP_patches (runtime wrappers around the game's
--     career modules).

local M = {}

local logTag = "careerMP"

local compat = nil
local patches = nil

local nickname = nil

local blockedInputActions = {}
local clientConfig

local careerMPActive = false
local syncRequested = false


local inComputerMenus = false

--Settings

local userTrafficSettings = {}
local careerMPTrafficSettings = {}

local userGameplaySettings = {}
local careerMPGameplaySettings = {}

local function getClientConfig()
	return clientConfig
end

-- The player's own values, saved before the first override of each join and put back
-- when they leave, so preferences changed between joins are kept.
local userSettingsSaved = false

local function getUserTrafficSettings()
	userTrafficSettings.trafficSmartSelections = settings.getValue('trafficSmartSelections')
	userTrafficSettings.trafficSimpleVehicles = settings.getValue('trafficSimpleVehicles')
	userTrafficSettings.trafficAllowMods = settings.getValue('trafficAllowMods')
end

local function setTrafficSettings(trafficSettings)
	for setting, value in pairs(trafficSettings) do
		settings.setValue(setting, value)
	end
end

local function getUserGameplaySettings()
	userGameplaySettings.simplifyRemoteVehicles = settings.getValue("simplifyRemoteVehicles")
	userGameplaySettings.spawnVehicleIgnitionLevel = settings.getValue("spawnVehicleIgnitionLevel")
	userGameplaySettings.skipOtherPlayersVehicles = settings.getValue("skipOtherPlayersVehicles")
end

local function setGameplaySettings(gameplaySettings)
	for setting, value in pairs(gameplaySettings) do
		settings.setValue(setting, value)
	end
end

--Hidden Nametags by Vehicle Model
-- Props, trailers and traffic that would otherwise spam nametags across the map.
local hiddens = {
	anticut = true, ball = true, barrels = true, barrier = true,
	barrier_plastic = true, blockwall = true, bollard = true, boxutility = true,
	boxutility_large = true, cannon = true, caravan = true, cardboard_box = true,
	cargotrailer = true, chair = true, christmas_tree = true, cones = true,
	containerTrailer = true, couch = true, crowdbarrier = true, delineator = true,
	dolly = true, dryvan = true, engine_props = true, flail = true,
	flatbed = true, flipramp = true, frameless_dump = true, fridge = true,
	gate = true, haybale = true, inflated_mat = true, kickplate = true,
	large_angletester = true, large_bridge = true, large_cannon = true,
	large_crusher = true, large_hamster_wheel = true, large_roller = true,
	large_spinner = true, large_tilt = true, large_tire = true,
	log_trailer = true, logs = true, mattress = true, metal_box = true,
	metal_ramp = true, piano = true, porta_potty = true, pressure_ball = true,
	rallyflags = true, rallysigns = true, rallytape = true, roadsigns = true,
	rocks = true, rollover = true, roof_crush_tester = true, sawhorse = true,
	shipping_container = true, simple_traffic = true, spikestrip = true,
	steel_coil = true, streetlight = true, suspensionbridge = true,
	tanker = true, testroller = true, tiltdeck = true, tirestacks = true,
	tirewall = true, trafficbarrel = true, trampoline = true, trashbin = true,
	tsfb = true, tub = true, tube = true, tv = true, wall = true,
	weightpad = true, woodcrate = true, woodplanks = true,
}

--Vehicles and part paints

-- The last state the server sent for each vehicle, by server vehicle id:
-- {active = <boolean>, traffic = <boolean or nil>}.
local knownStates = {}

-- BeamMP draws a player's nametag over every vehicle their game owns, so it is hidden on
-- a hidden car, a prop or trailer, and a car the owner's game marks as traffic or parked.
local function nametagHidden(jbeam, state)
	if hiddens[jbeam] then return true end
	if type(state) ~= "table" then return false end
	return state.active == false or state.traffic == true
end

-- Puts the server's last state on another player's car on this game; false when the
-- car is not here yet, is our own, or the server never sent its state.
local function applyKnownState(serverVehicleID)
	local state = knownStates[serverVehicleID]
	local entry = MPVehicleGE.getVehicles()[serverVehicleID]
	local gameVehicleID = entry and entry.gameVehicleID
	if not state or not gameVehicleID or gameVehicleID == -1 or MPVehicleGE.isOwn(gameVehicleID) then return false end
	local veh = be:getObjectByID(gameVehicleID)
	if not veh then return false end
	-- Only a change is applied: switching an already active car on again disturbs its
	-- physics on this screen, and a full list arrives every time a car spawns anywhere.
	local active = state.active and true or false
	if veh:getActive() ~= active then
		veh:setActive(active and 1 or 0)
	end
	entry.hideNametag = nametagHidden(entry.jbeam, state)
	return true
end

-- Career constantly hides/shows vehicles (garage, shopping, missions). A vehicle
-- hidden locally must be hidden for everyone, so the server keeps the
-- authoritative active-state map and we apply it to everything we do not own. The
-- server sends the whole map on request and one entry per change otherwise.
local function rxCareerVehSync(data)
	if data == "null" then return end
	local vehicleStates = jsonDecode(data)
	if type(vehicleStates) ~= "table" then return end
	for serverVehicleID, state in pairs(vehicleStates) do
		if type(state) == "table" then
			knownStates[serverVehicleID] = state
			applyKnownState(serverVehicleID)
		end
	end
end

--Traffic marks
--
-- Only the owner's game knows which of its cars are traffic or parked: the game flags
-- them (AI in the traffic data, isTraffic, isParked), and the models are ordinary cars.
-- Once a second the owner's game sends the marks that changed; the server stores them
-- with each car's state and passes them on.

local MARKS_EVERY_SECONDS = 1
local sinceMarks = 0

-- The mark last sent for each own vehicle: {gameVehicleID, mark}. The game id tells a
-- car apart from a new one BeamMP gave the same server id.
local sentMarks = {}

local function isAiTraffic(gameVehicleID)
	if not gameplay_traffic or type(gameplay_traffic.getTrafficData) ~= "function" then return false end
	local entry = (gameplay_traffic.getTrafficData() or {})[gameVehicleID]
	return type(entry) == "table" and entry.isAi == true
end

-- The car the player is in is theirs to drive, even one taken from traffic.
local function isTrafficCar(gameVehicleID, veh)
	if gameVehicleID == be:getPlayerVehicleID(0) then return false end
	if veh.isTraffic == "true" or veh.isParked == "true" then return true end
	return isAiTraffic(gameVehicleID)
end

local function sendTrafficMarks()
	local changed, seen = nil, {}
	for serverVehicleID, entry in pairs(MPVehicleGE.getVehicles()) do
		local gameVehicleID = entry.gameVehicleID
		if gameVehicleID and gameVehicleID ~= -1 and MPVehicleGE.isOwn(gameVehicleID) then
			local veh = be:getObjectByID(gameVehicleID)
			if veh then
				seen[serverVehicleID] = true
				local mark = isTrafficCar(gameVehicleID, veh)
				local sent = sentMarks[serverVehicleID]
				local previous = sent and sent.gameVehicleID == gameVehicleID and sent.mark or false
				if mark ~= previous then
					changed = changed or {}
					changed[serverVehicleID] = mark
				end
				sentMarks[serverVehicleID] = {gameVehicleID = gameVehicleID, mark = mark}
			end
		end
	end
	for serverVehicleID in pairs(sentMarks) do
		if not seen[serverVehicleID] then sentMarks[serverVehicleID] = nil end
	end
	if changed then TriggerServerEvent("careerVehicleTrafficMarks", jsonEncode(changed)) end
end

local function updateTrafficMarks(dtReal)
	local dt = tonumber(dtReal)
	if dt and dt > 0 then sinceMarks = sinceMarks + dt end
	if sinceMarks < MARKS_EVERY_SECONDS then return end
	sinceMarks = 0
	sendTrafficMarks()
end

local function onVehicleActiveChanged(gameVehicleID, active)
	if not gameVehicleID then return end
	if MPVehicleGE.isOwn(gameVehicleID) then
		local serverVehicleID = MPVehicleGE.getServerVehicleID(gameVehicleID)
		if serverVehicleID then
			TriggerServerEvent("careerVehicleActiveHandler", jsonEncode({
				active = active,
				serverVehicleID = serverVehicleID,
			}))
		end
	else
		-- Another player's car changed here. Applying the server's own update needs no
		-- answer; any other change is put right from the server's full map.
		local serverVehicleID = MPVehicleGE.getServerVehicleID(gameVehicleID)
		local known = serverVehicleID and knownStates[serverVehicleID]
		if known and (known.active and true or false) == (active and true or false) then return end
		TriggerServerEvent("careerVehSyncRequested", "")
	end
end

local function onVehicleSpawned(gameVehicleID)
	if not gameVehicleID then return end
	local veh = be:getObjectByID(gameVehicleID)
	if veh then
		veh:queueLuaCommand('careerMPEnabler.onVehicleReady()')
	end
	if MPVehicleGE.isOwn(gameVehicleID) then return end
	-- A car BeamMP builds after its state arrived takes the kept state.
	local serverVehicleID = MPVehicleGE.getServerVehicleID(gameVehicleID)
	if not (serverVehicleID and applyKnownState(serverVehicleID)) then
		TriggerServerEvent("careerVehSyncRequested", "")
	end
end

-- The ghost setting last queued to each car, by game vehicle id. onUpdate queues it only
-- when it differs; a car whose vehicle Lua restarted (ready again) or was reset is
-- forgotten, so it gets the setting again.
local appliedGhost = {}

local function forgetGhost(gameVehicleID)
	if gameVehicleID then appliedGhost[gameVehicleID] = nil end
end

local function onVehicleReady(gameVehicleID)
	forgetGhost(gameVehicleID)
	local serverVehicleID = MPVehicleGE.getServerVehicleID(gameVehicleID)
	if not serverVehicleID then return end
	local veh = be:getObjectByID(gameVehicleID)
	if not veh then return end

	if not MPVehicleGE.isOwn(gameVehicleID) then
		-- The game's own "not traffic" flag: its traffic checks it before adopting the
		-- player's car, so spectating this car never hands it to this game's traffic and
		-- police (gameplay/traffic.lua checkPlayer).
		veh:setDynDataFieldbyName("ignoreTraffic", 0, "true")
		-- Ghosting is not queued here: the vehicle side only has setGhost, and it is
		-- applied in onUpdate against the server's ghost config keys.
		local vehicles = MPVehicleGE.getVehicles()
		if vehicles[serverVehicleID] then
			vehicles[serverVehicleID].hideNametag = nametagHidden(veh.JBeam, knownStates[serverVehicleID])
		end
	end
	-- Raised so other players stay visible at big-map distances.
	veh:setField('renderDistance', '', 1610)
end

-- Re-entrancy guard.
--
-- Everything this handler does to correct a bad switch - enterNextVehicle,
-- setWalkingMode, enterVehicle - switches vehicles again, and the engine fires
-- onVehicleSwitched synchronously for each. Without a guard the handler calls
-- itself through the engine: entering a unicycle while inComputerMenus was set
-- recursed until the Lua stack overflowed, which showed up as walking mode simply
-- not working (the overflow surfaced inside gameplay_walk.toggleWalkingMode).
local handlingVehicleSwitch = false

-- While the camera sits on another player's car, this game's traffic would follow the
-- camera once the player's own car stops (gameplay/traffic.lua falls back to the camera
-- below 5 m/s), respawning around the car being watched. So spectating pins the traffic
-- focus on the own car the player left, and returning to an own car hands it back.
local trafficFocusPinned = false

local function updateTrafficFocus(oldGameVehicleID, newGameVehicleID)
	local newIsOwn = MPVehicleGE.isOwn(newGameVehicleID)
	local oldIsOwn = oldGameVehicleID ~= nil and oldGameVehicleID ~= -1
		and be:getObjectByID(oldGameVehicleID) ~= nil and MPVehicleGE.isOwn(oldGameVehicleID)
	if newIsOwn and not trafficFocusPinned then return end
	if not newIsOwn and not oldIsOwn then return end
	local c = compat or extensions.careerMP_compat
	local setFocus = c and c.pickOrWarn(gameplay_traffic, "gameplay_traffic", "setFocus",
		"traffic follows the camera while spectating")
	if not setFocus then return end
	if newIsOwn then
		setFocus()
		trafficFocusPinned = false
	else
		setFocus('vehicle', {vehId = oldGameVehicleID, auto = false})
		trafficFocusPinned = true
	end
end

local function handleVehicleSwitch(oldGameVehicleID, newGameVehicleID)
	local newVeh = be:getObjectByID(newGameVehicleID)
	local oldVeh = be:getObjectByID(oldGameVehicleID)
	if not newVeh then return end

	updateTrafficFocus(oldGameVehicleID, newGameVehicleID)

	-- Never let the player end up controlling someone else's prop.
	if hiddens[newVeh.JBeam] and not MPVehicleGE.isOwn(newGameVehicleID) then
		be:enterNextVehicle(0, 1)
		return
	end

	-- Career's computer menus act on the vehicle the player occupies, so being
	-- dropped onto the unicycle mid-menu has to be undone. Clear the flag first:
	-- this is a one-shot correction, and leaving it set arms the same branch for
	-- every future switch.
	if newVeh.JBeam == "unicycle" and inComputerMenus then
		inComputerMenus = false
		gameplay_walk.setWalkingMode(false)
		if oldVeh then be:enterVehicle(0, oldVeh) end
	end
end

local function onVehicleSwitched(oldGameVehicleID, newGameVehicleID)
	if handlingVehicleSwitch then return end
	handlingVehicleSwitch = true
	local ok, err = pcall(handleVehicleSwitch, oldGameVehicleID, newGameVehicleID)
	handlingVehicleSwitch = false
	if not ok then
		log("E", logTag, "onVehicleSwitched failed: " .. tostring(err))
	end
end

--Traffic Signals and Cameras

-- A player's AI traffic counts as that player's own vehicles in multiplayer, so a
-- traffic car caught by a camera would be announced under the player's name
-- (isAiTraffic, above).

local function onSpeedTrapTriggered(speedTrapData, playerSpeed, overSpeed)
	if not MPVehicleGE.isOwn(speedTrapData.subjectID) then return end
	if isAiTraffic(speedTrapData.subjectID) then return end
	local veh = be:getObjectByID(speedTrapData.subjectID)
	if not veh then return end
	local highscore, leaderboard = gameplay_speedTrapLeaderboards.addRecord(speedTrapData, playerSpeed, overSpeed, veh)
	speedTrapData.licensePlate = veh:getDynDataFieldbyName("licenseText", 0) or "Illegible"
	speedTrapData.vehicleModel = core_vehicles.getModel(veh.JBeam).model.Name
	speedTrapData.playerSpeed = playerSpeed
	speedTrapData.overSpeed = overSpeed
	speedTrapData.highscore = highscore
	speedTrapData.leaderboard = leaderboard
	TriggerServerEvent("speedTrap", jsonEncode(speedTrapData))
end

local function onRedLightCamTriggered(redLightData, playerSpeed)
	if not MPVehicleGE.isOwn(redLightData.subjectID) then return end
	if isAiTraffic(redLightData.subjectID) then return end
	local veh = be:getObjectByID(redLightData.subjectID)
	if not veh then return end
	redLightData.licensePlate = veh:getDynDataFieldbyName("licenseText", 0) or "Illegible"
	redLightData.vehicleModel = core_vehicles.getModel(veh.JBeam).model.Name
	redLightData.playerSpeed = playerSpeed
	TriggerServerEvent("redLight", jsonEncode(redLightData))
end

local function rxTrafficSignalTimer(data)
	core_trafficSignals.setTimer(tonumber(data))
end

--Garage / Office Computer Handling

-- Career's computer menus act on the vehicle the player occupies. In MP the
-- player is usually walking, so put them in the target vehicle first. Fed by the
-- enriched hooks from careerMP_patches, which carry the vehicle id that the
-- stock hooks omit.
local function computerMenuHandler(targetVehicleID)
	if not targetVehicleID then return end
	local veh = be:getObjectByID(targetVehicleID)
	if not veh or veh.JBeam == "unicycle" then return end
	if gameplay_walk.isWalking() then
		gameplay_walk.getInVehicle(veh)
	else
		be:enterVehicle(0, veh)
	end
	inComputerMenus = true
end

local function onComputerOpenedMP()
	inComputerMenus = false
end

--Patch BeamMP behavior and topBar

-- 0.39 deleted ui/topBar.lua and ui/topBar/ outright. The replacement stack
-- (menuManager + router + uiStateManager + pause/) has no removeEntry
-- equivalent -- the entry list now lives behind the router / pause-V2 layer.
-- Gated rather than removed so the old path still works if BeamNG restores it.
local function patchTopBar()
	if not compat.hasLegacyTopBar() then return end
	ui_topBar.removeEntry("environment")
	ui_topBar.removeEntry("mods")
	ui_topBar.removeEntry("vehicleconfig")
	ui_topBar.removeEntry("vehicles")
	local entries = ui_topBar.getEntries()
	ui_topBar.updateEntries(entries)
	ui_topBar.updateVisibleItems()
end

-- The mirrored driver side on remote vehicles is corrected by BeamMP itself
-- (beammp_multiplayer installs core_camera.getDriverData). BeamMP re-asserts
-- getDriverData from its own onUpdate every frame, so wrapping it would produce the
-- same mutual recursion documented in careerMP/patches.lua. Leave it alone.

--Initial Syncs and Updates

local function actionsCheck()
	blockedInputActions = {}
	if not clientConfig.consoleEnabled then
		table.insert(blockedInputActions, "toggleConsoleNG")
	end
	if not clientConfig.worldEditorEnabled then
		table.insert(blockedInputActions, "editorToggle")
		table.insert(blockedInputActions, "editorSafeModeToggle")
		table.insert(blockedInputActions, "objectEditorToggle")
	end
	extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
	extensions.core_input_actionFilter.addAction(0, 'careerMP', #blockedInputActions > 0)
end

local function saveUserSettings()
	if userSettingsSaved then return end
	getUserTrafficSettings()
	getUserGameplaySettings()
	userSettingsSaved = true
end

local function restoreUserSettings()
	if not userSettingsSaved then return end
	setTrafficSettings(userTrafficSettings)
	setGameplaySettings(userGameplaySettings)
	userSettingsSaved = false
end

local function settingsCheck()
	saveUserSettings()
	careerMPTrafficSettings.trafficAllowMods = clientConfig.trafficAllowMods
	careerMPTrafficSettings.trafficSimpleVehicles = clientConfig.trafficSimpleVehicles
	careerMPTrafficSettings.trafficSmartSelections = clientConfig.trafficSmartSelections
	setTrafficSettings(careerMPTrafficSettings)
	careerMPGameplaySettings.simplifyRemoteVehicles = clientConfig.simplifyRemoteVehicles
	careerMPGameplaySettings.spawnVehicleIgnitionLevel = clientConfig.spawnVehicleIgnitionLevel
	careerMPGameplaySettings.skipOtherPlayersVehicles = clientConfig.skipOtherPlayersVehicles
	setGameplaySettings(careerMPGameplaySettings)
end

-- Profile name = sanitised BeamMP nickname (or the server-configured name),
-- plus the server's suffix. Sanitising here keeps the mapping deterministic
-- across clients; see compat.sanitizeProfileName.
local function resolveProfileName()
	local base = MPConfig.getNickname()
	if clientConfig and clientConfig.serverSaveNameEnabled and clientConfig.serverSaveName ~= "" then
		base = clientConfig.serverSaveName
	end
	local suffix = (clientConfig and clientConfig.serverSaveSuffix) or ""
	return compat.sanitizeProfileName(tostring(base) .. tostring(suffix))
end

--Join: one loading screen, then the career or a reported failure
--
-- On a join the map is already loaded, so the game's career start opens its own
-- 'careerActivate' loading screen and closes it only after every career-active handler
-- has run; one failing handler leaves it open for good. CareerMP therefore:
--   * holds the map's loading screen under JOIN_HOLD_TAG from world-ready 1, so the
--     career's screens join it instead of showing a second one;
--   * runs the start under a traceback handler and closes the career's screens itself
--     when the start fails;
--   * tells the server the outcome (careerStartResult), so a player whose career cannot
--     start is dropped instead of waiting forever.

local JOIN_HOLD_TAG = "careerMPJoin"
local JOIN_MAX_SECONDS = 60          -- matches the server's limit from settings request to start
local TRAFFIC_SCREEN_MAX_SECONDS = 30
local CAREER_SCREEN_TAGS = {"careerActivate", "careerVehicles"}
local REASON_MAX_LENGTH = 200

-- hold:  time the join hold was taken, while CareerMP holds the loading screen
-- start: {since, level, ...} from the career start until it settles
local function newJoin()
	return {hold = nil, start = nil, reported = false, navigated = false}
end

local join = newJoin()

local function currentLevel()
	return type(getCurrentLevelIdentifier) == "function" and getCurrentLevelIdentifier() or nil
end

local function openCareerScreens()
	local open = {}
	for _, tag in ipairs(CAREER_SCREEN_TAGS) do
		if compat.getLoadingStatus(tag) then table.insert(open, tag) end
	end
	return open
end

local function holdJoinLoadingScreen()
	if join.hold or careerMPActive or not compat.isMPSession() then return end
	if compat.requestEnterLoadingScreen(JOIN_HOLD_TAG) then
		join.hold = os.clockhp()
		log("I", logTag, "join: holding the loading screen until the career starts")
	end
end

local function releaseJoinHold(why)
	if not join.hold then return end
	join.hold = nil
	compat.requestExitLoadingScreen(JOIN_HOLD_TAG)
	log("I", logTag, "join: loading screen released (" .. why .. ")")
end

-- BeamMP moves the interface to the in-game screen when its loading screen clears; the
-- held screen clears later, so the same step is repeated once it has.
local function moveToPlay()
	if join.navigated or join.hold or #openCareerScreens() > 0 then return end
	join.navigated = true
	compat.navigateToPlay()
end

local function reportCareerStart(started, reason)
	if join.reported then return end
	join.reported = true
	local payload = {started = started}
	if not started then payload.reason = reason end
	TriggerServerEvent("careerStartResult", jsonEncode(payload))
	if started then
		log("I", logTag, "join: career start confirmed to the server")
	else
		log("E", logTag, "join: career start failed, reported to the server: " .. reason)
	end
end

local function firstLine(text)
	local line = tostring(text):match("^[^\n]*") or ""
	return line:sub(1, REASON_MAX_LENGTH)
end

local function failCareerStart(reason)
	for _, tag in ipairs(openCareerScreens()) do
		compat.requestExitLoadingScreen(tag)
		log("W", logTag, "join: closed loading screen '" .. tag .. "' left open by the failed career start")
	end
	join.start = nil
	releaseJoinHold("career start failed")
	reportCareerStart(false, firstLine(reason))
	moveToPlay()
end

-- The game's insurance records do not always load on a join, which breaks Repair and the
-- Insurances page (see careerMP/insuranceRestore.lua). A failing check is logged and the
-- join still completes: a broken repair screen is less harmful than a dropped player.
local function ensureInsuranceLoaded()
	local restore = extensions.careerMP_insuranceRestore
	if not restore then
		log("E", logTag, "join: careerMP_insuranceRestore is not loaded - insurance records not checked")
		return
	end
	local ok, err = pcall(restore.ensureLoaded)
	if not ok then
		log("E", logTag, "join: insurance check failed: " .. firstLine(err))
	end
end

-- Per frame while the career start settles: it is done once the career is active and
-- its loading screens are released.
local function updateCareerStart()
	local start = join.start
	if not start then return end
	local elapsed = os.clockhp() - start.since

	if not start.trafficReleased and elapsed >= TRAFFIC_SCREEN_MAX_SECONDS
			and compat.getLoadingStatus("careerVehicles") then
		start.trafficReleased = true
		compat.releaseCareerTrafficScreen()
		log("W", logTag, string.format("join: traffic never reported ready - released loading screen " ..
			"'careerVehicles' after %ds", TRAFFIC_SCREEN_MAX_SECONDS))
	end

	if not start.levelChangeLogged and currentLevel() ~= start.level then
		start.levelChangeLogged = true
		log("W", logTag, string.format("join: the career start changed the map from '%s' to '%s' " ..
			"(the save names another map)", tostring(start.level), tostring(currentLevel())))
	end

	local open = openCareerScreens()
	if #open == 0 and compat.isCareerActive() ~= false then
		join.start = nil
		log("I", logTag, "join: career active")
		releaseJoinHold("career active")
		ensureInsuranceLoaded()
		reportCareerStart(true)
		moveToPlay()
		return
	end

	if #open > 0 and not start.waitLogged then
		start.waitLogged = true
		log("I", logTag, "join: waiting for loading screens still open: " .. table.concat(open, ", "))
	end

	if elapsed >= JOIN_MAX_SECONDS then
		failCareerStart(string.format("career start did not finish within %ds (loading screens open: %s; career active: %s)",
			JOIN_MAX_SECONDS, #open > 0 and table.concat(open, ", ") or "none", tostring(compat.isCareerActive())))
	end
end

-- The hold never outlasts the server's limit, whatever the career start is doing.
local function updateJoinHold()
	if join.hold and os.clockhp() - join.hold >= JOIN_MAX_SECONDS then
		log("W", logTag, string.format("join: loading screen '%s' held for %ds - releasing",
			JOIN_HOLD_TAG, JOIN_MAX_SECONDS))
		releaseJoinHold("time limit")
		moveToPlay()
	end
end

local function rxCareerSync(data)
	clientConfig = jsonDecode(data)
	if not clientConfig then
		log("E", logTag, "rxCareerSync: could not decode client config")
		failCareerStart("could not read the server's CareerMP settings")
		return
	end
	log("I", logTag, "join: settings received")
	nickname = MPConfig.getNickname()
	settingsCheck()
	actionsCheck()

	if careerMPActive or join.start then return end

	-- Must be in place before the career activates, or activation deletes every
	-- other player's vehicle.
	local careerPatches = extensions.careerMP_careerPatches
	if not (careerPatches and careerPatches.ensure()) then
		log("E", logTag, "career patches not applied - refusing to start career " ..
			"(would delete other players' vehicles)")
		failCareerStart("career vehicle protection not available")
		return
	end

	local profileName = resolveProfileName()
	log("I", logTag, string.format("join: career start begun for profile '%s' (nickname '%s', startMode '%s')",
		profileName, tostring(nickname), compat.defaultStartMode))
	join.start = {since = os.clockhp(), level = currentLevel()}

	-- The shield has to wrap this call, not activateCareer.
	--
	-- career.lua's createOrLoadCareerAndStart invokes its *local* activateCareer() with
	-- no arguments, so removeVehicles defaults to true and it runs
	-- core_vehicles.removeAll() -- wiping every vehicle in the level, including other
	-- players' cars. A wrapper on career_career.activateCareer never sees that call,
	-- because a local call does not go through the module table. Observed live: a second
	-- player joining deleted the first player's car on their own screen the instant
	-- their career activated.
	local ok, started = careerPatches.withRemoteVehiclesProtected(function()
		return compat.createOrLoadCareerAndStart(profileName, false, compat.defaultStartMode)
	end)

	if not ok then
		failCareerStart(started)
		return
	end
	if not started then
		failCareerStart("could not set career profile '" .. profileName .. "'")
		return
	end
	careerMPActive = true
	updateCareerStart()
end

local function rxClientConfigUpdate(data)
	local decoded = jsonDecode(data)
	if not decoded then return end
	clientConfig = decoded
	settingsCheck()
	actionsCheck()
end

-- Career activation spawns the player's own starter vehicle; drop the BeamMP
-- vehicles we already own so we do not end up with duplicates. Never touches
-- vehicles owned by other players.
local function onCareerActive(active)
	if not (active and careerMPActive) then return end
	local vehicles = MPVehicleGE.getVehicles()
	for _, vehicle in pairs(vehicles) do
		if vehicle.isLocal and vehicle.jbeam ~= "unicycle" then
			local veh = be:getObjectByID(vehicle.gameVehicleID)
			if veh then veh:delete() end
		end
	end
end

-- World-ready 1 comes while the map's loading screen is still up, so the hold taken
-- there keeps that same screen up. The settings request says this client confirms its
-- career start, so the server waits for careerStartResult instead of counting the
-- request as a started career.
local function onWorldReadyState(state)
	if state == 1 then
		holdJoinLoadingScreen()
	elseif state == 2 and not syncRequested then
		TriggerServerEvent("prefabSyncRequested", "")
		TriggerServerEvent("careerSyncRequested", jsonEncode({confirmsStart = true}))
		syncRequested = true
		log("I", logTag, "join: world ready, settings requested")
	end
end

local function onClientPostStartMission(levelPath)
	patchTopBar()
end

local function onUpdate(dtReal, dtSim, dtRaw)
	updateCareerStart()
	updateJoinHold()
	if worldReadyState ~= 2 or not clientConfig then return end
	updateTrafficMarks(dtReal)
	local vehicles = MPVehicleGE.getVehicles()
	for serverVehicleID in pairs(vehicles) do
		local gameVehicleID = vehicles[serverVehicleID].gameVehicleID
		local veh = be:getObjectByID(gameVehicleID)
		if veh then
			local ghost = nil
			if not MPVehicleGE.isOwn(gameVehicleID) then
				ghost = veh.JBeam == "unicycle" and clientConfig.remoteUnicycleGhost or clientConfig.remoteVehicleGhost
			elseif veh.JBeam == "unicycle" then
				ghost = clientConfig.localUnicycleGhost
			end
			if ghost ~= nil and appliedGhost[gameVehicleID] ~= ghost then
				appliedGhost[gameVehicleID] = ghost
				veh:queueLuaCommand(string.format('careerMPEnabler.setGhost(%s)', tostring(ghost)))
			end
		end
	end
end

--Loading / Unloading

local function onExtensionLoaded()
	compat = extensions.careerMP_compat
	patches = extensions.careerMP_patches
	if not compat then
		log("E", logTag, "careerMP_compat failed to load - aborting")
		return false
	end

	compat.report()

	nickname = MPConfig.getNickname()

	AddEventHandler("rxCareerSync", rxCareerSync)
	AddEventHandler("rxClientConfigUpdate", rxClientConfigUpdate)
	AddEventHandler("rxCareerVehSync", rxCareerVehSync)
	AddEventHandler("rxTrafficSignalTimer", rxTrafficSignalTimer)

	log("I", logTag, "CareerMP Enabler LOADED (target BeamNG " .. compat.targetGameVersion .. ")")
end

local function onExtensionUnloaded()
	releaseJoinHold("CareerMP unloaded")
	log("I", logTag, "CareerMP Enabler UNLOADED")
end

-- BeamMP fires onBeamMPServerLeave when the player leaves a server (MPCoreNetwork
-- leaveServer). Resetting the join state here is what lets a rejoin in the same game
-- session start the career again.
local function onBeamMPServerLeave()
	blockedInputActions = {}
	extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
	extensions.core_input_actionFilter.addAction(0, 'careerMP', false)
	restoreUserSettings()
	releaseJoinHold("left the server")
	join = newJoin()
	careerMPActive = false
	syncRequested = false
	knownStates = {}
	sentMarks = {}
	sinceMarks = 0
	trafficFocusPinned = false
	appliedGhost = {}
end

--Access

M.getClientConfig = getClientConfig
M.isTrafficCar = isTrafficCar

M.onCareerActive = onCareerActive

M.onVehicleActiveChanged = onVehicleActiveChanged
M.onVehicleSpawned = onVehicleSpawned
M.onVehicleReady = onVehicleReady
M.onVehicleSwitched = onVehicleSwitched
M.onVehicleResetted = forgetGhost
M.onVehicleDestroyed = forgetGhost

M.onSpeedTrapTriggered = onSpeedTrapTriggered
M.onRedLightCamTriggered = onRedLightCamTriggered

M.onComputerOpenedMP = onComputerOpenedMP

-- Enriched hooks published by careerMP_patches. The stock hooks carry no
-- vehicle id, so the patches add it.
M.onCareerTuningStartedMP = computerMenuHandler
M.onPartShoppingStartedMP = computerMenuHandler
M.onVehiclePaintingUiOpenedMP = computerMenuHandler
M.onPerformanceTestStartedMP = computerMenuHandler

M.onClientPostStartMission = onClientPostStartMission

M.onWorldReadyState = onWorldReadyState
M.onUpdate = onUpdate

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded

M.onBeamMPServerLeave = onBeamMPServerLeave

M.onInit = function() setExtensionUnloadMode(M, 'manual') end

return M
